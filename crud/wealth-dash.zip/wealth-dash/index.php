<?php include("header.php")?>
                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">

                                    <div class="page-body">
                                        <div class="row">


                                            <style>
                                                .theme-bg {
                                                    background: linear-gradient(135deg, #61ae41, #4e9b33);
                                                }

                                                .theme-text {
                                                    color: #61ae41;
                                                }

                                                .dashboard-card {
                                                    border-radius: 15px;
                                                    overflow: hidden;
                                                    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
                                                }

                                                .profile-avatar {
                                                    width: 55px;
                                                    height: 55px;
                                                    border-radius: 50%;
                                                    border: 3px solid #fff;
                                                }

                                                .label-title {
                                                    font-size: 14px;
                                                    color: #666;
                                                }

                                                .label-value {
                                                    font-size: 16px;
                                                    font-weight: 600;
                                                    color: #222;
                                                }

                                                .copylink input {
                                                    border-radius: 8px;
                                                    font-size: 14px;
                                                }

                                                .copylink button {
                                                    border-radius: 8px;
                                                }
                                            </style>

                                            <div class="container mt-4">
                                                <div class="row">

                                                    <style>
                                                        .theme-bg {
                                                            background: linear-gradient(135deg, #61ae41, #3d7f28);
                                                        }

                                                        .theme-text {
                                                            color: #61ae41;
                                                        }

                                                        .dashboard-card {
                                                            border-radius: 16px;
                                                            overflow: hidden;
                                                            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.18);
                                                            transition: 0.3s;
                                                        }

                                                        .dashboard-card:hover {
                                                            transform: translateY(-4px);
                                                        }

                                                        .profile-avatar {
                                                            width: 60px;
                                                            height: 60px;
                                                            border-radius: 50%;
                                                            border: 3px solid #fff;
                                                        }

                                                        .label-title {
                                                            font-size: 13px;
                                                            color: #888;
                                                        }

                                                        .label-value {
                                                            font-size: 16px;
                                                            font-weight: 600;
                                                            color: #222;
                                                        }

                                                        .copylink input {
                                                            border-radius: 10px;
                                                            font-size: 14px;
                                                        }

                                                        .copylink button {
                                                            border-radius: 10px;
                                                        }

                                                        .details-icon {
                                                            font-size: 18px;
                                                            margin-right: 6px;
                                                            color: #61ae41;
                                                        }
                                                    </style>

                                                    <div class="container mt-4">
                                                        <div class="row">

                                                            <!-- ============ LEFT : ACCOUNT DETAILS ============ -->
                                                            <div class="col-lg-6 mb-4">
                                                                <div class="card dashboard-card border-0">

                                                                    <div
                                                                        class="card-header theme-bg text-white d-flex align-items-center">
                                                                        <img src="assets/images/avatar-3.jpg"
                                                                            class="profile-avatar me-3">
                                                                        <div>
                                                                            <h4 style="margin-left: 10px;"
                                                                                class="mb-0 text-white">
                                                                                Account Details</h4>
                                                                            <small style="margin-left: 10px;">Secure
                                                                                Member Profile</small>
                                                                        </div>
                                                                    </div>

                                                                    <div class="card-body">

                                                                        <div class="row mb-3">
                                                                            <div class="col-6">
                                                                                <div class="label-title">
                                                                                    <i
                                                                                        class="fa fa-id-card details-icon"></i>
                                                                                    User ID
                                                                                </div>
                                                                                <div class="label-value">WS000001</div>
                                                                            </div>

                                                                            <div class="col-6">
                                                                                <div class="label-title">
                                                                                    <i
                                                                                        class="fa fa-shield details-icon"></i>
                                                                                    KYC Status
                                                                                </div>
                                                                                <span
                                                                                    class="badge theme-bg text-white px-3 py-2">Verified</span>
                                                                            </div>
                                                                        </div>

                                                                        <div class="row mb-2">
                                                                            <div class="col-6">
                                                                                <div class="label-title">
                                                                                    <i
                                                                                        class="fa fa-calendar details-icon"></i>
                                                                                    Registration Date
                                                                                </div>
                                                                                <div class="label-value">12 Jan 2025
                                                                                </div>
                                                                            </div>

                                                                            <div class="col-6">
                                                                                <div class="label-title">
                                                                                    <i
                                                                                        class="fa fa-check-circle details-icon"></i>
                                                                                    Activation Date
                                                                                </div>
                                                                                <div class="label-value">15 Jan 2025
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- ============ RIGHT : REFERRAL LINKS ============ -->
                                                            <div class="col-lg-6 mb-4">
                                                                <div class="card dashboard-card border-0">

                                                                    <div class="card-header theme-bg text-white">
                                                                        <h5 style="color:white" class="mb-0"><i
                                                                                style="color: white; font-size:20px"
                                                                                class="fa fa-share-alt"></i>
                                                                            Referral Links</h5>
                                                                        <small>Invite & Grow Your Network</small>
                                                                    </div>

                                                                    <div class="card-body">

                                                                        <!-- LEFT REFERRAL -->
                                                                        <div class="mb-4">
                                                                            <div class="label-value mb-1 theme-text">
                                                                                <i class="fa fa-arrow-left"></i> Left
                                                                                Referral Link
                                                                            </div>

                                                                            <div class="copylink d-flex">
                                                                                <input type="text" class="form-control"
                                                                                    id="referlink"
                                                                                    value="https://wealthixssolutionsinfo.org/registrationrr.php?ref_id=WS000001&position=left"
                                                                                    readonly>

                                                                                <button onclick="myFunction()"
                                                                                    class="btn text-white ms-2 theme-bg">
                                                                                    <i class="fa fa-files-o"></i>
                                                                                </button>
                                                                            </div>
                                                                        </div>

                                                                        <!-- RIGHT REFERRAL -->
                                                                        <div>
                                                                            <div class="label-value mb-1 theme-text">
                                                                                <i class="fa fa-arrow-right"></i> Right
                                                                                Referral Link
                                                                            </div>

                                                                            <div class="copylink d-flex">
                                                                                <input type="text" class="form-control"
                                                                                    id="referlink1"
                                                                                    value="https://wealthixssolutionsinfo.org/registrationrr.php?ref_id=WS000001&position=right"
                                                                                    readonly>

                                                                                <button onclick="myFunction1()"
                                                                                    class="btn text-white ms-2 theme-bg">
                                                                                    <i class="fa fa-files-o"></i>
                                                                                </button>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <!-- ========= COPY SCRIPT ========= -->
                                                    <script>
                                                        function myFunction() {
                                                            var copyText = document.getElementById("referlink");
                                                            copyText.select();
                                                            document.execCommand("Copy");
                                                            alert("✅ Left Referral Link Copied Successfully");
                                                        }

                                                        function myFunction1() {
                                                            var copyText = document.getElementById("referlink1");
                                                            copyText.select();
                                                            document.execCommand("Copy");
                                                            alert("✅ Right Referral Link Copied Successfully");
                                                        }
                                                    </script>


                                                </div>
                                            </div>

                                            <!-- ================= COPY SCRIPT ================= -->
                                            <script>
                                                function myFunction() {
                                                    var copyText = document.getElementById("referlink");
                                                    copyText.select();
                                                    document.execCommand("Copy");
                                                    alert("✅ Left Referral Link Copied Successfully");
                                                }

                                                function myFunction1() {
                                                    var copyText = document.getElementById("referlink1");
                                                    copyText.select();
                                                    document.execCommand("Copy");
                                                    alert("✅ Right Referral Link Copied Successfully");
                                                }
                                            </script>

                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ICON -->
                                                        <i
                                                            class="icofont icofont-users-alt-3 bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-green f-w-600">Left Team <br>
                                                            Business</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 750,000</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">

                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-group m-r-10"></i>
                                                                Team : 1
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <!-- card1 end -->
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ICON -->
                                                        <i class="icofont icofont-users-alt-6 bg-c-pink card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-pink f-w-600">Right Team <br>
                                                            Business</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 1,250,000</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-pink f-16 icofont icofont-group m-r-10"></i>
                                                                Team : 3
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <!-- card1 end -->
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ FIXED ICON -->
                                                        <i class="icofont icofont-users bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-green f-w-600">Matching Team <br>
                                                            Business</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 520,000</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-group m-r-10"></i>
                                                                Team : 2
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <!-- card1 end -->
                                            <!-- card1 start -->
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-green f-w-600">Today <br> Matching
                                                            Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-green f-w-600">Total <br> Matching
                                                            Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-green f-w-600">Total <br> Matching
                                                            Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>


                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-gift bg-c-green card1-icon mb-2"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-blue f-w-600 d-block">Reward &
                                                            Bonus<br>Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>





                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-gift bg-c-green card1-icon mb-2"></i>

                                                        <!-- TITLE -->
                                                        <span class="text-c-blue f-w-600 d-block">Reward &
                                                            Bonus<br>Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>





                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Royalty
                                                            <br>Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>





                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>

                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Non-working
                                                            <br>Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Updated Today
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>





                                            </div>



                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Top-up Daily
                                                            <br>Level Income (600)</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Top-up Daily
                                                            <br>Level Income (1200)</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-money-bag bg-c-green card1-icon"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Top-up Daily
                                                            <br>Level Income (2400)</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>


                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>

                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Left
                                                            <br>Repurchase BV</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>


                                                <!-- box new  -->









                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Right
                                                            <br> Repurchase BV</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>

                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Repurchase
                                                            <br> Business</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-exchange m-r-10"></i>


                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 14px;"
                                                            class="text-c-blue f-w-600 d-block">Today Repurchase
                                                            <br> Matching Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 14px;"
                                                            class="text-c-blue f-w-600 d-block">Re-purchase
                                                            <br> Self Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Re-purchase
                                                            <br> Level Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i
                                                            class="icofont icofont-ui-home bg-c-green card1-icon mb-2"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Family
                                                            <br> Support Fund </span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i class="icofont icofont-cart bg-c-green card1-icon mr-3"></i>


                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Weekly
                                                            <br> Total Income</span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>
                                            <div class="col-md-6 col-xl-3">
                                                <div class="card widget-card-1">
                                                    <div class="card-block-small">

                                                        <!-- ✅ ICON -->
                                                        <i
                                                            class="icofont icofont-money-bag bg-c-green card1-icon mb-2"></i>

                                                        <!-- TITLE -->
                                                        <span style="font-size: 16px;"
                                                            class="text-c-blue f-w-600 d-block">Total
                                                            <br> Income </span>

                                                        <!-- MAIN VALUE -->
                                                        <h4>₹ 2,500</h4>

                                                        <!-- EXTRA INFO -->
                                                        <div>
                                                            <span class="f-left m-t-10 text-muted">
                                                                <i
                                                                    class="text-c-green f-16 icofont icofont-calendar m-r-10"></i>
                                                                Expire Date: 05-12-2025
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>







                                            </div>












                                        </div>
                                    </div>
                                </div>

                                <div id="styleSelector">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Warning Section Starts -->
    <!-- Older IE warning message -->
    <!--[if lt IE 9]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade <br/>to any of the following web browsers to access this website.</p>
    <div class="iew-container">
        <ul class="iew-download">
            <li>
                <a href="http://www.google.com/chrome/">
                    <img src="assets/images/browser/chrome.png" alt="Chrome">
                    <div>Chrome</div>
                </a>
            </li>
            <li>
                <a href="https://www.mozilla.org/en-US/firefox/new/">
                    <img src="assets/images/browser/firefox.png" alt="Firefox">
                    <div>Firefox</div>
                </a>
            </li>
            <li>
                <a href="http://www.opera.com">
                    <img src="assets/images/browser/opera.png" alt="Opera">
                    <div>Opera</div>
                </a>
            </li>
            <li>
                <a href="https://www.apple.com/safari/">
                    <img src="assets/images/browser/safari.png" alt="Safari">
                    <div>Safari</div>
                </a>
            </li>
            <li>
                <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                    <img src="assets/images/browser/ie.png" alt="">
                    <div>IE (9 & above)</div>
                </a>
            </li>
        </ul>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>
<![endif]-->
    <!-- Warning Section Ends -->
    <!-- Required Jquery -->
   <?php include('footer.php')?>