        <?php
        include "config.php";

        if (!isset($_GET['id'])) {
            die("Product not found");
        }

        $id = intval($_GET['id']);

        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();

        if (!$product) {
            die("Invalid Product ID");
        }
        ?>
        <!DOCTYPE html>
        <html>

        <head>
            <title><?= $product['title'] ?></title>
            <style>
                body {
                    font-family: Arial;
                    background: #f5f5f5;
                    padding: 30px;
                }

                .container {
                    background: white;
                    padding: 25px;
                    border-radius: 10px;
                    width: 900px;
                    margin: auto;
                    display: flex;
                    gap: 40px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }

                img {
                    width: 380px;
                    border-radius: 10px;
                    object-fit: contain;
                }

                .btn {
                    padding: 12px 25px;
                    font-size: 18px;
                    border: none;
                    cursor: pointer;
                    border-radius: 8px;
                }

                .cart {
                    background: #ff3e6c;
                    color: white;
                }

                .buy {
                    background: #f0c14b;
                    margin-left: 15px;
                }
            </style>
        </head>

        <body>

            <a href="index.php" style="text-decoration:none; font-size:20px;">⬅ Back</a>

            <div class="container">
                <div>
                    <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="Product Image">
                </div>

                <div>
                    <h1><?= htmlspecialchars($product['title']) ?></h1>
                    <h2 style="color:green;">₹<?= number_format($product['price']) ?></h2>

                    <p style="margin:20px 0; font-size:18px;">
                        <?= nl2br(htmlspecialchars($product['description'])) ?>
                    </p>

                    <form method="POST" action="add-to-cart.php">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <label>Quantity: </label>
                        <input type="number" name="qty" value="1" min="1" max="10" style="padding:6px; width:60px;">
                        <br><br>
                        <button type="submit" class="btn cart">Add to Cart 🛒</button>
                        <button type="button" onclick="alert('Buying System Soon Available')" class="btn buy">Buy Now ⚡</button>
                    </form>
                </div>
            </div>

        </body>

        </html>