<?php include "config.php"; ?>

<h1>Our Products</h1>
<div style="display:flex; flex-wrap:wrap; gap:20px;">
<?php
$products = $pdo->query("SELECT * FROM products");
foreach($products as $p){
  echo "
  <div style='width:250px; border:1px solid #ddd; padding:10px; text-align:center'>
    <img src='uploads/$p[image]' style='width:100%; height:200px; object-fit:cover;'>
    <h3>$p[title]</h3>
    <p>₹$p[price]</p>
    <a href='product.php?id=$p[id]' style='padding:8px 12px; background:black; color:white;'>View Details</a>
  </div>";
}
?>
</div>
