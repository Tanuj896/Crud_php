<?php
include "../config.php";

// Delete Product
if (isset($_GET['delete'])) {
  $id = $_GET['delete'];
  $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
  $stmt->execute([$id]);
  header("Location: products.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Admin - Products</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

  <div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2 class="fw-bold">All Products</h2>
      <a href="add_product.php" class="btn btn-primary">+ Add Product</a>
    </div>

    <div class="table-responsive shadow-sm rounded">
      <table class="table table-striped table-hover align-middle mb-0">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Image</th>
            <th>Title</th>
            <th>Price</th>
            <th width="160">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $products = $pdo->query("SELECT * FROM products ORDER BY id DESC");
          foreach ($products as $p) {
            echo "
          <tr>
            <td>$p[id]</td>
            <td><img src='../uploads/$p[image]' class='img-fluid rounded' style='width:60px; height:60px; object-fit:cover;'></td>
            <td class='fw-semibold'>$p[title]</td>
            <td class='fw-bold text-success'>₹$p[price]</td>
            <td>
              <a href='edit_product.php?id=$p[id]' class='btn btn-sm btn-warning'>Edit</a>
              <a href='products.php?delete=$p[id]' onclick='return confirm(\"Delete Product?\")' class='btn btn-sm btn-danger'>Delete</a>
            </td>
          </tr>";
          }
          ?>
        </tbody>
      </table>
    </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>