<?php
include "../config.php";

$id = $_GET['id'];

// Fetch product details
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (isset($_POST['update'])) {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    // if new image uploaded
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "../uploads/" . $image);
    } else {
        $image = $product['image']; // keep old image
    }

    $stmt = $pdo->prepare("UPDATE products SET title=?, price=?, description=?, image=? WHERE id=?");
    $stmt->execute([$title, $price, $description, $image, $id]);

    header("Location: products.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container py-4" style="max-width: 700px;">

        <h2 class="fw-bold mb-4">✏️ Edit Product</h2>

        <form method="POST" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-sm">

            <div class="mb-3">
                <label class="form-label fw-semibold">Product Title</label>
                <input type="text" name="title" class="form-control" value="<?= $product['title'] ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Price (₹)</label>
                <input type="number" name="price" class="form-control" value="<?= $product['price'] ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Description</label>
                <textarea name="description" class="form-control" rows="5"><?= $product['description'] ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold d-block">Current Image</label>
                <img src="../uploads/<?= $product['image'] ?>" class="img-fluid rounded border mb-2" style="max-width: 180px;">
                <input type="file" name="image" class="form-control">
            </div>

            <button type="submit" name="update" class="btn btn-success w-100 py-2 fw-bold">Update Product</button>

        </form>

        <a href="products.php" class="btn btn-dark mt-3 w-100">⬅ Back to Dashboard</a>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>