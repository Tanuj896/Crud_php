<?php
include "../config.php";

if (isset($_POST['upload'])) {
  $title = $_POST['title'];
  $price = $_POST['price'];
  $description = $_POST['description'];

  $image = $_FILES['image']['name'];
  $imageSize = $_FILES['image']['size'];
  $tmp = $_FILES['image']['tmp_name'];

  // 10 KB validation (10 KB = 10240 bytes)
  if ($imageSize > 10240) {
    $error = "Image size must be less than 10 KB!";
  } else {
    $target = "../uploads/" . basename($image);
    move_uploaded_file($tmp, $target);

    $stmt = $pdo->prepare("INSERT INTO products(title, price, description, image) VALUES (?,?,?,?)");
    $stmt->execute([$title, $price, $description, $image]);

    header("Location: products.php?success=1");
    exit;
  }
}
?>
<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Add Product</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
  <div class="container py-4" style="max-width: 700px;">

    <h2 class="fw-bold mb-4">➕ Add New Product</h2>

    <?php if (isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
      <div class="alert alert-success">Product Added Successfully!</div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-sm">

      <div class="mb-3">
        <label class="form-label fw-semibold">Product Title</label>
        <input type="text" name="title" class="form-control" placeholder="Enter product name" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Price (₹)</label>
        <input type="number" name="price" class="form-control" placeholder="Enter price" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Description</label>
        <textarea name="description" class="form-control" rows="5" placeholder="Enter product details"></textarea>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold">Product Image</label>
        <input type="file" name="image" class="form-control" required>
        <small class="text-secondary">Max size allowed: <b>10 KB</b></small>
      </div>

      <button type="submit" name="upload" class="btn btn-success w-100 py-2 fw-bold">Add Product</button>
    </form>

    <a href="products.php" class="btn btn-dark mt-3 w-100">⬅ Back to Dashboard</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>