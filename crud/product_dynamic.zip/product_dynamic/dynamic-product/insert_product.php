<?php
require 'config.php';

function slugify($text)
{
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return $text ?: 'n-a';
}

$name = $_POST['name'] ?? '';
$price = $_POST['price'] ?? 0;
$stock = $_POST['stock'] ?? 0;
$description = $_POST['description'] ?? '';
$slug = slugify($name);

$imagePath = null;
if (!empty($_FILES['image']['name'])) {
    $uploadsDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadsDir)) mkdir($uploadsDir, 0755, true);

    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    if (!in_array(strtolower($ext), $allowed)) {
        die('Invalid image type');
    }

    $newName = uniqid('prod_') . '.' . $ext;
    $destination = $uploadsDir . $newName;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
        $imagePath = 'uploads/' . $newName;
    }
}

try {
    $stmt = $pdo->prepare("INSERT INTO products (name, slug, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $slug, $description, $price, $stock, $imagePath]);
    header('Location: index.php?msg=created');
    exit;
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
