<style>
        /* style.css */

        body {
                font-family: Arial, sans-serif;
                padding: 20px;
                background-color: #f5f5f5;
        }

        h2 {
                color: #333;
        }

        a {
                display: inline-block;
                margin: 10px 0;
                text-decoration: none;
                color: #0066cc;
        }

        form {
                background-color: #fff;
                padding: 20px;
                border-radius: 8px;
                max-width: 400px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form input[type="text"],
        form input[type="email"],
        form input[type="file"],
        form button {
                width: 100%;
                padding: 10px;
                margin: 8px 0;
                box-sizing: border-box;
                border: 1px solid #ccc;
                border-radius: 4px;
        }

        form button {
                background-color: #28a745;
                color: white;
                border: none;
                font-weight: bold;
                cursor: pointer;
        }

        form button:hover {
                background-color: #218838;
        }

        table {
                width: 100%;
                border-collapse: collapse;
                background-color: #fff;
                margin-top: 20px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table th,
        table td {
                padding: 12px 15px;
                border: 1px solid #ddd;
                text-align: left;
        }

        table th {
                background-color: #007bff;
                color: white;
        }

        img {
                width: 60px;
                height: 60px;
                object-fit: cover;
                border-radius: 4px;
        }
</style>
<?php
include 'db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];

$imageName = $_FILES['image']['name'];
$tmpName = $_FILES['image']['tmp_name'];
$uploadPath = "data/" . $imageName;
move_uploaded_file($tmpName, $uploadPath);

$sql = "INSERT INTO employees (name, email, phone, image) 
        VALUES ('$name', '$email', '$phone', '$imageName')";
$conn->query($sql);

header("Location: display.php");
?>