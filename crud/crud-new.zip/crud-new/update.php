<?php
include 'db.php';

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM employees WHERE id=$id");
$row = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    if ($_FILES['image']['name'] != "") {
        $imageName = $_FILES['image']['name'];
        $tmpName = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmpName, "data/$imageName");
        $conn->query("UPDATE employees SET name='$name', email='$email', phone='$phone', image='$imageName' WHERE id=$id");
    } else {
        $conn->query("UPDATE employees SET name='$name', email='$email', phone='$phone' WHERE id=$id");
    }

    header("Location: display.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #e0f7fa, #f1f8e9);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            animation: fadeIn 1s ease-in-out;
        }

        form {
            background: white;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            gap: 15px;
            min-width: 320px;
            animation: slideIn 0.8s ease-out;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="email"],
        input[type="file"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }

        input:focus {
            outline: none;
            border-color: #4a90e2;
            box-shadow: 0 0 5px rgba(74, 144, 226, 0.5);
        }

        button {
            padding: 12px;
            background: #2196F3;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #0b7dda;
        }

        img {
            width: 60px;
            border-radius: 50%;
            border: 2px solid #1976D2;
            align-self: center;
            margin-top: 5px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <form method="POST" enctype="multipart/form-data">
        <h2>Edit Employee</h2>
        <input type="text" name="name" value="<?= $row['name'] ?>" required>
        <input type="email" name="email" value="<?= $row['email'] ?>" required>
        <input type="text" name="phone" value="<?= $row['phone'] ?>" required>
        <input type="file" name="image">
        <img src="data/<?= $row['image'] ?>" alt="Current Image">
        <button type="submit" name="update">Update</button>
    </form>
</body>

</html>