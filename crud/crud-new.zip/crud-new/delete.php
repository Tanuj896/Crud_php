<?php
include 'db.php';

$id = $_GET['id'];

// Fetch image name
$getImage = $conn->query("SELECT image FROM employees WHERE id=$id");
$row = $getImage->fetch_assoc();
$image = $row['image'];

// Delete image file
if (file_exists("data/$image")) {
    unlink("data/$image");
}

// Delete database record
$conn->query("DELETE FROM employees WHERE id=$id");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Deleting...</title>
    <style>
        body {
            background-color: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-family: Arial, sans-serif;
        }

        .message-box {
            text-align: center;
            padding: 30px 50px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 1s ease-in-out;
        }

        .loader {
            border: 6px solid #f3f3f3;
            border-top: 6px solid #3498db;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            margin: 20px auto;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
</head>

<body>
    <div class="message-box">
        <h2>Deleting Record...</h2>
        <div class="loader"></div>
        <p>You will be redirected shortly.</p>
    </div>

    <script>
        setTimeout(() => {
            window.location.href = "display.php";
        }, 2000); // 2 second delay
    </script>
</body>

</html>