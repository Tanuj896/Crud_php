<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>

<head>
  <title>Employee Records</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(to right, #e3f2fd, #ffffff);
      padding: 40px;
      text-align: center;
    }

    h2 {
      margin-bottom: 20px;
      color: #2c3e50;
      animation: slideDown 0.7s ease-in-out;
    }

    a {
      text-decoration: none;
      background: #4CAF50;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
      margin-bottom: 20px;
      display: inline-block;
      transition: 0.3s ease;
    }

    a:hover {
      background: #388E3C;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background-color: #ffffff;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      overflow: hidden;
      animation: fadeIn 1s ease-in;
    }

    th,
    td {
      padding: 15px;
      border-bottom: 1px solid #ddd;
      color: #333;
    }

    th {
      background-color: #1976D2;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    img {
      border-radius: 50%;
      border: 2px solid #1976D2;
    }

    td a {
      margin: 0 5px;
      padding: 6px 10px;
      border-radius: 5px;
      font-weight: bold;
    }

    td a[href*="update"] {
      background-color: #2196F3;
      color: white;
    }

    td a[href*="delete"] {
      background-color: #f44336;
      color: white;
    }

    td a:hover {
      opacity: 0.85;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: scale(0.95);
      }

      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    @keyframes slideDown {
      from {
        transform: translateY(-20px);
        opacity: 0;
      }

      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
  </style>
</head>

<body>
  <h2>Employee List</h2>
  <a href="form.php">➕ Add New Employee</a>
  <table>
    <tr>
      <th>ID</th>
      <th>Image</th>
      <th>Name</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Action</th>
    </tr>

    <?php
    $result = $conn->query("SELECT * FROM employees ORDER BY id DESC");
    while ($row = $result->fetch_assoc()) {
      echo "<tr>
          <td>{$row['id']}</td>
          <td><img src='data/{$row['image']}' width='60' height='60'></td>
          <td>{$row['name']}</td>
          <td>{$row['email']}</td>
          <td>{$row['phone']}</td>
          <td>
            <a href='update.php?id={$row['id']}'>Edit</a> 
            <a href='delete.php?id={$row['id']}'>Delete</a>
          </td>
        </tr>";
    }
    ?>
  </table>
</body>

</html>