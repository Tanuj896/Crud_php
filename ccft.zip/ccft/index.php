<?php include('header.php'); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="web_assets/img/banners.png" alt="First slide">
                                </div>

                            </div>
                        </div>


                        <!-- Content Row -->


                        <!-- Content Row -->


                    </div>


                    <!-- /.container-fluid -->

                    <section class="py-5" style="background: #f8f9fa;">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-lg-10 text-center">

                                    <!-- Heading -->
                                    <h2 class="fw-bold mb-4 text-dark">About Defence Chanakya Academy</h2>

                                    <!-- Gradient Box -->
                                    <div class="p-5 rounded-4 shadow"
                                        style="background: linear-gradient(135deg, #d8c7f9, #f3d6c4);">
                                        <p class="mb-0 fs-5 text-dark">
                                            Defence Chanakya Academy is India's Premier institution established
                                            with the sole aim to initiate, enable and empower individuals to grow
                                            up to be extraordinary professionals.
                                        </p>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </section>


                </div>

<?php include('footer.php'); ?>
                       