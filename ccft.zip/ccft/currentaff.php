<?php include('header.php'); ?>
<!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>


    <div class="container py-5">
        <h3 class="text-center mb-4">Current Affairs</h3>

        <!-- Nav Pills -->
        <ul class="nav nav-pills justify-content-center mb-4" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-videos-tab" data-bs-toggle="pill" data-bs-target="#pills-videos" type="button" role="tab">Videos</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-pdfs-tab" data-bs-toggle="pill" data-bs-target="#pills-pdfs" type="button" role="tab">PDFs</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-images-tab" data-bs-toggle="pill" data-bs-target="#pills-images" type="button" role="tab">Images</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-daily-tab" data-bs-toggle="pill" data-bs-target="#pills-daily" type="button" role="tab">Daily</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-monthly-tab" data-bs-toggle="pill" data-bs-target="#pills-monthly" type="button" role="tab">Monthly</button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content" id="pills-tabContent">

            <!-- Videos -->
            <div class="tab-pane fade show active" id="pills-videos" role="tabpanel">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Video Lectures</h5>
                        <div class="row g-4">
                            <div class="col-md-6 col-lg-4">
                                <div class="ratio ratio-16x9">
                                    <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Video" allowfullscreen></iframe>
                                </div>
                                <p class="mt-2">Lecture 1: Introduction to Current Affairs</p>
                            </div>
                            <!-- More video cards here -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- PDFs -->
            <div class="tab-pane fade" id="pills-pdfs" role="tabpanel">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Download PDFs</h5>
                        <ul class="list-group">
                            <li class="list-group-item">
                                <a href="https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" target="_blank">
                                    Current Affairs - Jan 2025
                                </a>
                            </li>
                            <li class="list-group-item">
                                <a href="https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf" target="_blank">
                                    Current Affairs - Feb 2025
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Images -->
            <div class="tab-pane fade" id="pills-images" role="tabpanel">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Infographics</h5>
                        <div class="row g-4">
                            <div class="col-md-4">
                                <img src="https://via.placeholder.com/400x250" class="img-fluid rounded" alt="Infographic">
                                <p class="mt-2">Highlights of Current Affairs</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Daily -->
            <div class="tab-pane fade" id="pills-daily" role="tabpanel">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Daily Updates</h5>
                        <p>No daily updates available yet.</p>
                    </div>
                </div>
            </div>

            <!-- Monthly -->
            <div class="tab-pane fade" id="pills-monthly" role="tabpanel">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Monthly Updates</h5>
                        <p>Monthly compiled updates will appear here.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>




    <!-- Content Row -->


    <!-- Content Row -->


</div>


<!-- /.container-fluid -->




</div>

<?php include('footer.php'); ?>