<?php include('header.php'); ?>
<!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>

    <!-- Content Row -->

    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-4">Free Course</h2>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">

                <!-- Book Card 1 -->
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Science Injection">
                        <div class="card-body text-center">
                            <h5 class="card-title">Science Injection</h5>

                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>

                <!-- Book Card 2 -->
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="GK Book Version 1.5">
                        <div class="card-body text-center">
                            <h5 class="card-title">GK Book Version 1.5</h5>

                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>

                <!-- Book Card 3 (Extra Example) -->
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Mathematics Booster">
                        <div class="card-body text-center">
                            <h5 class="card-title">Mathematics Booster</h5>

                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    ```




    <!-- Content Row -->


    <!-- Content Row -->


</div>


<!-- /.container-fluid -->




</div>

<?php include('footer.php'); ?>