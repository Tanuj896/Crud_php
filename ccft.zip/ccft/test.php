<?php include('header.php'); ?>
<!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>

    <!-- Content Row -->
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>All Test Series</title>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>

        <div class="container py-5">
            <h2 class="text-center mb-4">All Test Series</h2>
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-100 text-center">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Test Series">
                        <div class="card-body">
                            <h5 class="card-title">Test Series Sainik / RMS 9th (2024)</h5>
                            <p class="card-text fw-bold">₹999</p>
                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-100 text-center">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Test Series">
                        <div class="card-body">
                            <h5 class="card-title">Test Series Sainik / RMS 6th (2024)</h5>
                            <p class="card-text fw-bold">₹999</p>
                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-100 text-center">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Test Series">
                        <div class="card-body">
                            <h5 class="card-title">RIMC Dec 2025</h5>
                            <p class="card-text fw-bold">₹999</p>
                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-100 text-center">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Test Series">
                        <div class="card-body">
                            <h5 class="card-title">RIMC Dec 2025</h5>
                            <p class="card-text fw-bold">₹999</p>
                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-100 text-center">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Test Series">
                        <div class="card-body">
                            <h5 class="card-title">RIMC Dec 2025</h5>
                            <p class="card-text fw-bold">₹999</p>
                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card h-100 text-center">
                        <img src="web_assets/img/logoo.webp" class="card-img-top" alt="Test Series">
                        <div class="card-body">
                            <h5 class="card-title">RIMC Dec 2025</h5>
                            <p class="card-text fw-bold">₹999</p>
                            <a href="#" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>



        <!-- Content Row -->


        <!-- Content Row -->


</div>


<!-- /.container-fluid -->




</div>

<?php include('footer.php'); ?>