<?php include('header.php'); ?>
<!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
    </div>

    <!-- Content Row -->
    <section class="py-5" style="background:#f9fafb;">
        <div class="container">

            <!-- Filter Buttons -->
            <div class="d-flex justify-content-center mb-5 flex-wrap gap-2">
                <button class="btn btn-primary rounded-pill px-4 py-2 fw-semibold">All Courses</button>
                <button class="btn btn-outline-primary rounded-pill px-4 py-2 fw-semibold">Sainik & Military</button>
                <button class="btn btn-outline-primary rounded-pill px-4 py-2 fw-semibold">RIMC</button>
            </div>

            <!-- Courses Grid -->
            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="card h-100 shadow-lg border-0 rounded-4">
                        <img src="web_assets/img/logoo.webp" class="card-img-top rounded-top-4" alt="RIMC">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold text-dark mb-3">RIMC DEC 2025</h5>
                            <p class="card-text text-muted flex-grow-1">
                                The Rashtriya Indian Military College is a military school for boys and girls situated...
                            </p>
                            <h6 class="fw-bold text-primary mb-3">₹20,000</h6>
                            <a href="#" class="btn btn-primary w-100 rounded-pill mt-auto">View Details</a>
                        </div>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="card h-100 shadow-lg border-0 rounded-4">
                        <img src="web_assets/img/logoo.webp" class="card-img-top rounded-top-4" alt="Sainik 6th">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold text-dark mb-3">Sainik | RMS Class 6th (2025)</h5>
                            <p class="card-text text-muted flex-grow-1">
                                The Sainik Schools are a system of public schools in India established and...
                            </p>
                            <h6 class="fw-bold text-primary mb-3">₹20,000</h6>
                            <a href="#" class="btn btn-primary w-100 rounded-pill mt-auto">View Details</a>
                        </div>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-sm-12 col-md-6 col-lg-4">
                    <div class="card h-100 shadow-lg border-0 rounded-4">
                        <img src="web_assets/img/logoo.webp" class="card-img-top rounded-top-4" alt="Sainik 9th">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold text-dark mb-3">Sainik | RMS Class 9th (2025)</h5>
                            <p class="card-text text-muted flex-grow-1">
                                The Sainik Schools are a system of public schools in India established and...
                            </p>
                            <h6 class="fw-bold text-primary mb-3">₹20,000</h6>
                            <a href="#" class="btn btn-primary w-100 rounded-pill mt-auto">View Details</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>




    <!-- Content Row -->


    <!-- Content Row -->


</div>


<!-- /.container-fluid -->




</div>

<?php include('footer.php'); ?>