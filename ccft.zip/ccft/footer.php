   <!-- End of Main Content -->

                <!-- Footer -->
                <footer style="background-color: #FBF9ED; margin-top:50px" class="sticky-footer py-4">
                    <div class="container my-auto">
                        <div class="row">

                            <!-- Logo Section -->
                            <div class="col-md-4 text-center text-md-start mb-3 mb-md-0">
                                <img src="web_assets/img/logoo.webp" alt="Logo" style=" width:120px; height:90px;">

                            </div>

                            <!-- Links Section -->
                            <div class="col-md-4 text-center mb-3 mb-md-0">
                                <h6>Quick Links</h6>
                                <ul class="list-unstyled">
                                    <li><a href="#">Home</a></li>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>
                            </div>

                            <!-- Contact Section -->
                            <div class="col-md-4 text-center text-md-end">
                                <h6>Contact Us</h6>
                                <p>Email: info@yourwebsite.com</p>
                                <p>Phone: +91-9876543210</p>
                                <p>Address: New Delhi, India</p>
                            </div>
                        </div>

                        <hr>
                        <div class="copyright text-center my-auto">
                            <span>&copy; 2025 Your Website. All Rights Reserved.</span>
                        </div>
                    </div>
                </footer>

                <!-- End of Footer -->

            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="login.html">Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="web_assets/vendor/jquery/jquery.min.js"></script>
        <script src="web_assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="web_assets/vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="web_assets/js/sb-admin-2.min.js"></script>

        <!-- Page level plugins -->
        <script src="web_assets/vendor/chart.js/Chart.min.js"></script>

        <!-- Page level custom scripts -->
        <script src="web_assets/js/demo/chart-area-demo.js"></script>
        <script src="web_assets/js/demo/chart-pie-demo.js"></script>

</body>

</html>